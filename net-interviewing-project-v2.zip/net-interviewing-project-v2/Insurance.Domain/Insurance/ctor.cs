﻿namespace Insurance.Domain.Insurance
{
    internal class ctor
    {
    }
}