﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Insurance.Product.Configs
{
    public class ProductApiConfig
    {
        public string BaseUrl { get; set; }
    }
}
