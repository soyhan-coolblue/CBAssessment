﻿using Insurance.Domain.Entities.Utility.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Insurance.Api.Middleware
{
    public class ErrorExceptionFilter : IActionFilter, IOrderedFilter
    {
        public int Order { get; } = int.MaxValue - 10;

        public void OnActionExecuting(ActionExecutingContext context) { }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Exception is ApiException exception)
            {
                context.Result = new ObjectResult(exception.Value)
                {
                    StatusCode = exception.StatusCode,
                };
                context.ExceptionHandled = true;
            }

            if (context.Exception is NotFoundException notFoundException)
            {
                context.Result = new ObjectResult(notFoundException.Value)
                {
                    Value = notFoundException.Message,
                    StatusCode = notFoundException.StatusCode,
                };
                context.ExceptionHandled = true;
            }
        }
    }
}
