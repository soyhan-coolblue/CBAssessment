﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Insurance.Api.Middleware
{
    public interface IApiExceptionFilter
    {
        void OnException(ExceptionContext context);
    }
}