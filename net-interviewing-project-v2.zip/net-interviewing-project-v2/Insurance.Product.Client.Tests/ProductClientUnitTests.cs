﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Insurance.Product.Client.Tests
{
    public class ProductClientUnitTests
    {

    }
}
